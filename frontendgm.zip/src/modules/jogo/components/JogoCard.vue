<template>
  <biblioteca-row>
    <biblioteca-col
      :sm="4"
      :md="2">
      <biblioteca-icon
        class="mt-2"
        size="xl"
        icon="book" />
    </biblioteca-col>
    <biblioteca-col
      :sm="20"
      :md="22">
      <biblioteca-header v-truncate size="sm">
        <biblioteca-livro-link :id="livro.id">{{ livro.nome }}</biblioteca-livro-link>
      </biblioteca-header>
    </biblioteca-col>
  </biblioteca-row>
</template>

<script>
import BibliotecaLivroLink from '@/modules/jogo/components/JogoLink.vue';

export default {
  name: 'LivroListItem',
  components: {
    BibliotecaLivroLink,
  },
  props: {
    livro: {
      type: Object,
      required: true,
    },
  },
};
</script>
